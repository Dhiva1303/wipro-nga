import React from 'react';

import ProductsUI from './Components/ProductsUI';

const App = () => {
  return (
    <div>
      <ProductsUI/>
      
    </div>
  )
}

export default App