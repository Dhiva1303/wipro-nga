import React from "react";
import ProductTable from "./components/ProductTable";

const App = () => {
  return (
    <>
      <ProductTable />
    </>
  );
};

export default App;
