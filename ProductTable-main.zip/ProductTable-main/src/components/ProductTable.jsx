import React from "react";
import { Table, Button, Form, Breadcrumb, ButtonGroup } from "react-bootstrap";
import "./ProductTable.css";

const products = [
  { id: 1, name: "Printed Cotton Jacket", price: "$45.00", stock: 999, low: 500 },
  { id: 2, name: "Blue Faux Leather", price: "$45.00", stock: 999, low: 500 },
  { id: 3, name: "Tribal Waterfall Vest", price: "$45.00", stock: 999, low: 500 },
  { id: 4, name: "Braver Bomber Jacket", price: "$45.00", stock: 999, low: 500 },
  { id: 5, name: "Olive Drape Vest", price: "$45.00", stock: 999, low: 500 },
  { id: 6, name: "Black Denim Jacket", price: "$45.00", stock: 999, low: 500 },
  { id: 7, name: "Army Green Jacket", price: "$45.00", stock: 999, low: 500 },
];

const ProductTable = () => {
  return (
    <>
      <div className="container mt-4">
        <div>
          <h3 className="title">Products</h3>
          <Breadcrumb>
            <Breadcrumb.Item href="#">Dashboard</Breadcrumb.Item>
            <Breadcrumb.Item active>Products</Breadcrumb.Item>
          </Breadcrumb>
        </div>
        <div className="d-flex gap-2 mb-3 justify-content-end">
          <ButtonGroup className="filter-group">
            <Button variant="primary" className="filter-btn active-btn">
              Active
            </Button>
            <Button variant="light" className="filter-btn">
              Inactive
            </Button>
            <Button variant="light" className="filter-btn">
              All
            </Button>
          </ButtonGroup>
        </div>
        <Table bordered hover className="product-table">
          <thead>
            <tr>
              <th rowSpan="2">
                <Form.Check type="checkbox" />
              </th>
              <th rowSpan="2">Product</th>
              <th rowSpan="2">Tags</th>
              <th colSpan="4" className="text-center">
                NYC Outlet
              </th>
            </tr>
            <tr>
              <th>Var</th>
              <th>Price</th>
              <th>Stock</th>
              <th>Low</th>
            </tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>
                  <Form.Check type="checkbox" />
                </td>
                <td>{product.name}</td>
                <td>
                  <span className="tag-badge">Unisex</span>
                  <span className="tag-badge">Bag</span>
                </td>
                <td>3</td>
                <td>{product.price}</td>
                <td>{product.stock}</td>
                <td>{product.low}</td>
              </tr>
            ))}
          </tbody>
        </Table>
      </div>
    </>
  );
};

export default ProductTable;
